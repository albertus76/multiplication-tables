const tableSelect = document.getElementById('table-select');
const generateTableButton = document.getElementById('generate-table');
const tableContainer = document.getElementById('table-container');
const tableNumberSpan = document.getElementById('table-number');
const tableList = document.getElementById('table-list');

const startGameButton = document.getElementById('start-game');
const resetGameButton = document.getElementById('reset-game');
const gameContainer = document.getElementById('game-container');
const questionElement = document.getElementById('question');
const answerInput = document.getElementById('answer');
const checkAnswerButton = document.getElementById('check-answer');
const resultElement = document.getElementById('result');

// Audio
const correctSound = new Audio('correct.mp3');
const incorrectSound = new Audio('incorrect.mp3');

let incorrectAnswers = 0;
const maxIncorrectAnswers = 3;

// Inizializzazione: nascondi la sezione delle tabelline all'avvio
tableContainer.style.display = 'none';

// Genera Tabellina
generateTableButton.addEventListener('click', function() {
    const tableNumber = parseInt(tableSelect.value);
    tableNumberSpan.textContent = tableNumber;

    tableList.innerHTML = ''; // Pulisci la lista

    for (let i = 1; i <= 10; i++) {
        const listItem = document.createElement('li');
        listItem.textContent = `${tableNumber} x ${i} = ${tableNumber * i}`;
        tableList.appendChild(listItem);
    }
});

// Inizia il Gioco
startGameButton.addEventListener('click', function() {
    incorrectAnswers = 0;
    tableContainer.style.display = 'none';
    gameContainer.style.display = 'block';
    generateQuestion();
});

// Reset Gioco
resetGameButton.addEventListener('click', function() {
    incorrectAnswers = 0;
    tableContainer.style.display = 'none';
    gameContainer.style.display = 'none';
});

// Genera Domanda
function generateQuestion() {
    const num1 = Math.floor(Math.random() * 9) + 2;
    const num2 = Math.floor(Math.random() * 9) + 2;
    const correctAnswer = num1 * num2;

    questionElement.textContent = `${num1} x ${num2} = ?`;
    answerInput.value = '';
    answerInput.focus();
}

// Controlla Risposta
checkAnswerButton.addEventListener('click', function() {
    checkAnswer();
});

// Controlla Risposta con tasto Invio
answerInput.addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        checkAnswer();
    }
});

function checkAnswer() {
    const userAnswer = parseInt(answerInput.value);
    const num1 = parseInt(questionElement.textContent.split(' x ')[0]);
    const num2 = parseInt(questionElement.textContent.split(' x ')[1].split(' = ')[0]);
    const correctAnswer = num1 * num2;

    if (userAnswer === correctAnswer) {
        resultElement.textContent = 'Corretto!';
        resultElement.style.color = 'green';
        correctSound.play();
    } else {
        resultElement.textContent = `Sbagliato. La risposta corretta è ${correctAnswer}.`;
        resultElement.style.color = 'red';
        incorrectSound.play();
        incorrectAnswers++;

        if (incorrectAnswers >= maxIncorrectAnswers) {
            showTables();
        }
    }

    setTimeout(() => {
        if (incorrectAnswers < maxIncorrectAnswers) {
            generateQuestion();
            resultElement.textContent = '';
        }
    }, 2000);
}

function showTables() {
    gameContainer.style.display = 'none';
    tableContainer.style.display = 'block';
    generateTableButton.click();
}